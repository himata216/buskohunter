/*
 * Copyright (c) Forge Development LLC and contributors
 * SPDX-License-Identifier: LGPL-2.1-only
 */

package net.minecraftforge.client.extensions;

import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.math.Transformation;

/**
 * Extension interface for {@link com.mojang.blaze3d.vertex.PoseStack}.
 */
public interface IForgePoseStack {
    private PoseStack self() {
        return (PoseStack)this;
    }

    /**
     * Pushes and applies the {@code transformation} to this pose stack. <br>
     * The effects of this method can be reversed by a corresponding {@link PoseStack#popPose()} call.
     *
     * @param transformation the transformation to push
     */
    default void pushTransformation(Transformation transformation) {
        final PoseStack self = self();
        self.pushPose();

        var trans = transformation.translation();
        self.translate(trans.x(), trans.y(), trans.z());

        self.last().rotate(transformation.leftRotation());

        var scale = transformation.scale();
        self.scale(scale.x(), scale.y(), scale.z());

        self.last().rotate(transformation.rightRotation());
    }
}
