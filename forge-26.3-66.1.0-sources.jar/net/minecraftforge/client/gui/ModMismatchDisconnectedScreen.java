/*
 * Copyright (c) Forge Development LLC and contributors
 * SPDX-License-Identifier: LGPL-2.1-only
 */

package net.minecraftforge.client.gui;

import java.net.URI;
import java.net.URISyntaxException;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import net.minecraftforge.client.gui.widget.ScrollPanel;
import org.apache.commons.lang3.tuple.Pair;

import com.mojang.blaze3d.Blaze3D;

import net.minecraft.ChatFormatting;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.client.gui.TextAlignment;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.components.MultiLineLabel;
import net.minecraft.client.gui.narration.NarrationElementOutput;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.client.input.MouseButtonEvent;
import net.minecraft.network.chat.ClickEvent;
import net.minecraft.network.chat.Component;
import net.minecraft.network.chat.HoverEvent;
import net.minecraft.network.chat.MutableComponent;
import net.minecraft.network.chat.Style;
import net.minecraft.resources.Identifier;
import net.minecraft.util.FormattedCharSequence;
import net.minecraftforge.common.ForgeI18n;
import net.minecraftforge.fml.ModList;
import net.minecraftforge.fml.loading.FMLPaths;
import net.minecraftforge.network.NetworkContext.NetworkMismatchData;
import net.minecraftforge.network.packets.ModVersions;

//TODO: [Forge][Rendering] Rewrite entire ModMismatch screen
//Oh god... Whoever wrote this was on something very very strong.
public class ModMismatchDisconnectedScreen extends Screen {
    private final Component reason;
    private MultiLineLabel message = MultiLineLabel.EMPTY;
    private final Screen parent;
    private int textHeight;
    private final Path modsDir;
    private final Path logFile;
    private final int listHeight;
    private final NetworkMismatchData data;
    private final boolean hasMismatches;

    private final List<String> allModIds;
    private final Map<String, String> presentModUrls;

    public ModMismatchDisconnectedScreen(Screen parentScreen, Component title, Component reason, NetworkMismatchData data) {
        super(title);
        this.parent = parentScreen;
        this.reason = reason;
        this.modsDir = FMLPaths.MODSDIR.get();
        this.logFile = FMLPaths.GAMEDIR.get().resolve(Paths.get("logs","latest.log"));
        this.data = data;
        this.hasMismatches = !data.mismatched().isEmpty() || !data.missing().isEmpty();
        this.listHeight = hasMismatches ? 140 : 0;

        this.allModIds = data.mods().keySet().stream().distinct().collect(Collectors.toList());
        this.presentModUrls = ModList.getMods().stream()
            .filter(info -> allModIds.contains(info.getModId()))
            .map(info -> Pair.of(info.getModId(), (String)info.getConfig().getConfigElement("displayURL").orElse("")))
            .collect(Collectors.toMap(Pair::getLeft, Pair::getRight));
    }

    @Override
    protected void init() {
        this.message = MultiLineLabel.create(this.font, this.reason, this.width - 50);
        this.textHeight = this.message.getLineCount() * 9;

        int listLeft = Math.max(8, this.width / 2 - 220);
        int listWidth = Math.min(440, this.width - 16);
        int upperButtonHeight = Math.min((this.height + this.listHeight + this.textHeight) / 2 + 10, this.height - 50);
        int lowerButtonHeight = Math.min((this.height + this.listHeight + this.textHeight) / 2 + 35, this.height - 25);
        if (hasMismatches)
            this.addRenderableWidget(new MismatchInfoPanel(minecraft, listWidth, listHeight, (this.height - this.listHeight) / 2, listLeft));

        int buttonWidth = Math.min(210, this.width / 2 - 20);
        this.addRenderableWidget(Button.builder(Component.literal(ForgeI18n.parseMessage("fml.button.open.file", logFile.getFileName())), _ -> Blaze3D.openPath(logFile))
                .bounds(Math.max(this.width / 4 - buttonWidth / 2, listLeft), upperButtonHeight, buttonWidth, 20)
                .build());
        this.addRenderableWidget(Button.builder(Component.literal(ForgeI18n.parseMessage("fml.button.open.mods.folder")), _ -> Blaze3D.openPath(modsDir))
                .bounds(Math.min(this.width * 3 / 4 - buttonWidth / 2, listLeft + listWidth - buttonWidth), upperButtonHeight, buttonWidth, 20)
                .build());
        this.addRenderableWidget(Button.builder(Component.translatable("gui.toMenu"), _ -> this.minecraft.gui.setScreen(this.parent))
                .bounds((this.width - buttonWidth) / 2, lowerButtonHeight, buttonWidth, 20)
                .build());
    }

    @Override
    public void extractRenderState(GuiGraphicsExtractor guiGraphics, int mouseX, int mouseY, float partialTicks) {
        int textYOffset = hasMismatches ? 18 : 0;
        guiGraphics.centeredText(this.font, this.title, this.width / 2, (this.height - this.listHeight - this.textHeight) / 2 - textYOffset - 9 * 2, 0xAAAAAA);
        var lineCollector = guiGraphics.textRenderer(GuiGraphicsExtractor.HoveredTextEffects.notClickable(false), null);
        this.message.visitLines(TextAlignment.CENTER, this.width / 2, (this.height - this.listHeight - this.textHeight) / 2 - textYOffset, 9, lineCollector);
        super.extractRenderState(guiGraphics, mouseX, mouseY, partialTicks);
    }

    class MismatchInfoPanel extends ScrollPanel {
        private final List<Pair<FormattedCharSequence, Pair<FormattedCharSequence, FormattedCharSequence>>> lineTable;
        private final int contentSize;
        private final int nameIndent = 10;
        private final int tableWidth = width - border * 2 - 6 - nameIndent;
        private final int nameWidth = tableWidth * 3 / 5;
        private final int versionWidth = (tableWidth - nameWidth) / 2;

        public MismatchInfoPanel(Minecraft client, int width, int height, int top, int left) {
            super(client, width, height, top, left);

            //The raw list of the strings in a table row, the components may still be too long for the final table and will be split up later. The first row element may have a style assigned to it that will be used for the whole content row.
            List<Pair<MutableComponent, Pair<String, String>>> rawTable = new ArrayList<>();
            if (!data.missing().isEmpty()) {
                //The header of the section, colored in gray
                rawTable.add(Pair.of(
                    Component.literal(ForgeI18n.parseMessage(data.fromServer() ? "fml.modmismatchscreen.missingmods.server" : "fml.modmismatchscreen.missingmods.client")).withStyle(ChatFormatting.GRAY),
                    null
                ));
                //This table section contains the mod name and mod version of each mod that has a missing remote counterpart (if the mod is missing on the server, the client mod version is displayed, and vice versa)
                rawTable.add(Pair.of(
                    Component.literal(ForgeI18n.parseMessage("fml.modmismatchscreen.table.modname")).withStyle(ChatFormatting.UNDERLINE),
                    Pair.of(
                        "",
                        ForgeI18n.parseMessage(data.fromServer() ? "fml.modmismatchscreen.table.youhave" : "fml.modmismatchscreen.table.youneed")
                    )
                ));
                int i = 0;
                for (Identifier mod : data.missing()) {
                    rawTable.add(Pair.of(
                        toModNameComponent(mod, data.mods().get(mod.getNamespace()).name(), i),
                        Pair.of(
                            "",
                            data.mods().getOrDefault(mod, new ModVersions.Info("", "")).version()
                        )
                    ));
                    if (++i >= 10) {
                        //If too many missing mod entries are present, append a line referencing how to see the full list and stop rendering any more entries
                        rawTable.add(Pair.of(
                            Component.literal(ForgeI18n.parseMessage("fml.modmismatchscreen.additional", data.missing().size() - i)).withStyle(ChatFormatting.ITALIC),
                            Pair.of("", "")
                        ));
                        break;
                    }
                }
                rawTable.add(Pair.of(Component.literal(" "), null)); //padding
            }

            if (!data.mismatched().isEmpty()) {
                //The header of the table section, colored in gray
                rawTable.add(Pair.of(Component.literal(ForgeI18n.parseMessage("fml.modmismatchscreen.mismatchedmods")).withStyle(ChatFormatting.GRAY), null));
                //This table section contains the mod name and both mod versions of each mod that has a mismatching client and server version
                rawTable.add(Pair.of(
                    Component.literal(ForgeI18n.parseMessage("fml.modmismatchscreen.table.modname")).withStyle(ChatFormatting.UNDERLINE),
                    Pair.of(
                        ForgeI18n.parseMessage(data.fromServer() ? "fml.modmismatchscreen.table.youhave" : "fml.modmismatchscreen.table.serverhas"),
                        ForgeI18n.parseMessage(data.fromServer() ? "fml.modmismatchscreen.table.serverhas" : "fml.modmismatchscreen.table.youhave")
                    )
                ));
                int i = 0;
                for (var modData : data.mismatched().entrySet()) {
                    rawTable.add(Pair.of(
                        toModNameComponent(modData.getKey(), data.mods().get(modData.getKey().getNamespace()).name(), i),
                        Pair.of(
                            data.mods().getOrDefault(modData.getKey(), new ModVersions.Info("", "")).version(),
                            modData.getValue().received()
                        )
                    ));
                    if (++i >= 10) {
                        //If too many mismatched mod entries are present, append a line referencing how to see the full list and stop rendering any more entries
                        rawTable.add(Pair.of(Component.literal(ForgeI18n.parseMessage("fml.modmismatchscreen.additional", data.mismatched().size() - i)).withStyle(ChatFormatting.ITALIC), Pair.of("", "")));
                        break;
                    }
                }
                rawTable.add(Pair.of(Component.literal(" "), null)); //padding
            }

            this.lineTable = rawTable.stream().flatMap(p -> splitLineToWidth(p.getKey(), p.getValue()).stream()).collect(Collectors.toList());
            this.contentSize = lineTable.size();
        }

        /**
         * Splits the raw name and version strings, making them use multiple lines if needed, to fit within the table dimensions.
         * The style assigned to the name element is then applied to the entire content row.
         * @param name The first element of the content row, usually representing a table section header or the name of a mod entry
         * @param versions The last two elements of the content row, usually representing the mod versions. If either one or both of them are not given, the first element may take up more space within the table.
         * @return A list of table rows consisting of 3 elements each which consist of the same content as was given by the parameters, but split up to fit within the table dimensions.
         */
        private List<Pair<FormattedCharSequence, Pair<FormattedCharSequence, FormattedCharSequence>>> splitLineToWidth(MutableComponent name, Pair<String, String> versions) {
            Style style = name.getStyle();
            int versionColumns = versions == null ? 0 : (versions.getLeft().isEmpty() ? (versions.getRight().isEmpty() ? 0 : 1) : 2);
            int adaptedNameWidth = nameWidth + versionWidth * (2 - versionColumns) - 4; //the name width may be expanded when the version column string is missing
            List<FormattedCharSequence> nameLines = font.split(name, adaptedNameWidth);
            List<FormattedCharSequence> clientVersionLines = font.split(Component.literal(versions != null ? versions.getLeft() : "").setStyle(style), versionWidth - 4);
            List<FormattedCharSequence> serverVersionLines = font.split(Component.literal(versions != null ? versions.getRight() : "").setStyle(style), versionWidth - 4);
            List<Pair<FormattedCharSequence, Pair<FormattedCharSequence, FormattedCharSequence>>> splitLines = new ArrayList<>();
            int rowsOccupied = Math.max(nameLines.size(), Math.max(clientVersionLines.size(), serverVersionLines.size()));
            for (int i = 0; i < rowsOccupied; i++) {
                splitLines.add(Pair.of(
                    i < nameLines.size() ? nameLines.get(i) : FormattedCharSequence.EMPTY,
                    versions == null ? null : Pair.of(
                        i < clientVersionLines.size() ? clientVersionLines.get(i) : FormattedCharSequence.EMPTY,
                        i < serverVersionLines.size() ? serverVersionLines.get(i) : FormattedCharSequence.EMPTY
                    )
                ));
            }
            return splitLines;
        }

        /**
         * Adds a style information to the given mod name string. The style assigned to the returned component contains the color of the mod name,
         * a hover event containing the given id, and an optional click event, which opens the homepage of mod, if present.
         * @param id An id that gets displayed in the hover event. Depending on the origin it may only consist of a namespace (the mod id) or a namespace + path (a channel id associated with the mod).
         * @param modName The name of the mod. It will be rendered as the main text component.
         * @param color Defines the color of the returned style information. An odd number will result in a yellow, an even one in a gold color. This color variation makes it easier for users to distinguish different mod entries.
         * @return A component with the mod name as the main text component, and an assigned style which will be used for the whole content row.
         */
        private MutableComponent toModNameComponent(Identifier id, String modName, int color) {
            String modId = id.getNamespace();
            String tooltipId = id.getPath().isEmpty() ? id.getNamespace() : id.toString();
            return Component.literal(modName).withStyle(color % 2 == 0 ? ChatFormatting.GOLD : ChatFormatting.YELLOW)
                    .withStyle(s -> s.withHoverEvent(new HoverEvent.ShowText(Component.literal(tooltipId + (!presentModUrls.getOrDefault(modId, "").isEmpty() ? "\n" + ForgeI18n.parseMessage("fml.modmismatchscreen.homepage") : "")))))
                    .withStyle(s -> s.withClickEvent(openUrl(presentModUrls.getOrDefault(modId, ""))));
        }

        private static ClickEvent.OpenUrl openUrl(String url) {
            try {
                return url.isEmpty() ? null : new ClickEvent.OpenUrl(new URI(url));
            } catch (URISyntaxException e) {
                return null;
            }
        }

        @Override
        protected int getContentHeight() {
            int height = contentSize * (font.lineHeight + 3);

            if (height < bottom - top - 4)
                height = bottom - top - 4;

            return height;
        }

        @Override
        protected void drawPanel(GuiGraphicsExtractor guiGraphics, int entryRight, int relativeY, int mouseX, int mouseY) {
            int i = 0;

            for (Pair<FormattedCharSequence, Pair<FormattedCharSequence, FormattedCharSequence>> line : lineTable) {
                FormattedCharSequence name = line.getLeft();
                Pair<FormattedCharSequence, FormattedCharSequence> versions = line.getRight();
                //Since font#draw does not respect the color of the given component, we have to read it out here and then use it as the last parameter
                int color = 0xFFFFFF; //Optional.ofNullable(font.substrByWidth(name, 0)).map(Style::getColor).map(TextColor::getValue).orElse(0xFFFFFF);
                //Only indent the given name if a version string is present. This makes it easier to distinguish table section headers and mod entries
                int nameLeft = left + border + (versions == null ? 0 : nameIndent);
                guiGraphics.text(font, name, nameLeft, relativeY + i * 12, color, false);
                if (versions != null) {
                    guiGraphics.text(font, versions.getLeft(), left + border + nameIndent + nameWidth, relativeY + i * 12, color, false);
                    guiGraphics.text(font, versions.getRight(), left + border + nameIndent + nameWidth + versionWidth, relativeY + i * 12, color, false);
                }

                i++;
            }
        }

        @Override
        public void extractRenderState(GuiGraphicsExtractor guiGraphics, int mouseX, int mouseY, float partialTicks) {
            super.extractRenderState(guiGraphics, mouseX, mouseY, partialTicks);
            Style style = getComponentStyleAt(mouseX, mouseY);
            if (style != null && style.getHoverEvent() != null)
                guiGraphics.componentHoverEffect(font, style, mouseX, mouseY);
        }

        public Style getComponentStyleAt(double x, double y) {
            if (this.isMouseOver(x, y)) {
                double relativeY = y - this.top + this.scrollDistance - border;
                int slotIndex = (int)(relativeY + (border / 2)) / 12;
                if (slotIndex < contentSize) {
                    //The relative x needs to take the potentially missing indent of the row into account. It does that by checking if the line has a version associated to it
                    //double relativeX = x - left - border - (lineTable.get(slotIndex).getRight() == null ? 0 : nameIndent);
                    //if (relativeX >= 0)
                    //    return font.getSplitter().componentStyleAtWidth(lineTable.get(slotIndex).getLeft(), (int)relativeX);
                }
            }

            return null;
        }

        @Override
        public boolean mouseClicked(MouseButtonEvent info, boolean recent) {
            Style style = getComponentStyleAt(info.x(), info.y());
            if (style != null) {
                //handleComponentClicked(style);
                return true;
            }
            return super.mouseClicked(info, recent);
        }

        @Override
        public NarrationPriority narrationPriority() {
            return NarrationPriority.NONE;
        }

        @Override
        public void updateNarration(NarrationElementOutput output) {
        }
    }
}
